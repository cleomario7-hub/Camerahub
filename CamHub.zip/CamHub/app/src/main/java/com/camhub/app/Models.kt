package com.camhub.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Camera(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val host: String = "",
    val rtspPort: Int = 554,
    val user: String = "",
    val pass: String = "",
    val path1: String = "/onvif1",
    val path2: String = "",
    val onvifPort: Int = 80,
) {
    /** Câmera de duas lentes: tem um segundo caminho de vídeo. */
    val dual: Boolean get() = path2.isNotBlank()

    /** Monta a URL RTSP (sem usuário/senha; as credenciais vão como opções do player). */
    fun url(lens: Int): String {
        val p = (if (lens == 2) path2 else path1).trim()
        if (p.startsWith("rtsp://", ignoreCase = true)) return p
        return "rtsp://$host:$rtspPort" + if (p.startsWith("/")) p else "/$p"
    }
}

data class Preset(
    val label: String,
    val path1: String,
    val path2: String,
    val rtspPort: Int,
    val onvifPort: Int,
    val user: String = "",
)

val PRESETS = listOf(
    Preset("YCC365 Plus", "/onvif1", "/onvif2", 554, 80, "admin"),
    Preset("Yoosee", "/onvif1", "/onvif2", 554, 80, "admin"),
    Preset("Tapo / TP-Link", "/stream1", "/stream2", 554, 2020),
    Preset("Intelbras / Dahua", "/cam/realmonitor?channel=1&subtype=0", "/cam/realmonitor?channel=2&subtype=0", 554, 80, "admin"),
    Preset("Hikvision", "/Streaming/Channels/101", "/Streaming/Channels/201", 554, 80, "admin"),
)

class CameraStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("camhub", Context.MODE_PRIVATE)

    fun load(): List<Camera> {
        val raw = sp.getString("cameras", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Camera(
                    id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                    name = o.optString("name"),
                    host = o.optString("host"),
                    rtspPort = o.optInt("rtspPort", 554),
                    user = o.optString("user"),
                    pass = o.optString("pass"),
                    path1 = o.optString("path1", "/onvif1"),
                    path2 = o.optString("path2"),
                    onvifPort = o.optInt("onvifPort", 80),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<Camera>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(
                JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("host", c.host)
                    put("rtspPort", c.rtspPort)
                    put("user", c.user)
                    put("pass", c.pass)
                    put("path1", c.path1)
                    put("path2", c.path2)
                    put("onvifPort", c.onvifPort)
                }
            )
        }
        sp.edit().putString("cameras", arr.toString()).apply()
    }
}
