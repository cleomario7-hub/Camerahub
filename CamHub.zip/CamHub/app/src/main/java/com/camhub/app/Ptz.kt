package com.camhub.app

import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Cliente ONVIF mínimo (SOAP sobre HTTP) com autenticação WS-Security. */
object Onvif {
    private const val WSSE =
        "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
    private const val WSU =
        "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"
    private const val PROFILE =
        "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0"

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun security(user: String, pass: String, digest: Boolean): String {
        if (user.isBlank()) return ""
        if (!digest) {
            return """<Security xmlns="$WSSE"><UsernameToken><Username>${esc(user)}</Username><Password Type="$PROFILE#PasswordText">${esc(pass)}</Password></UsernameToken></Security>"""
        }
        val nonce = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val created = fmt.format(Date())
        val md = MessageDigest.getInstance("SHA-1")
        md.update(nonce)
        md.update(created.toByteArray())
        md.update(pass.toByteArray())
        val d = Base64.encodeToString(md.digest(), Base64.NO_WRAP)
        val n = Base64.encodeToString(nonce, Base64.NO_WRAP)
        return """<Security xmlns="$WSSE"><UsernameToken><Username>${esc(user)}</Username><Password Type="$PROFILE#PasswordDigest">$d</Password><Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">$n</Nonce><Created xmlns="$WSU">$created</Created></UsernameToken></Security>"""
    }

    private fun envelope(user: String, pass: String, body: String, digest: Boolean): String =
        """<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Header>${security(user, pass, digest)}</s:Header><s:Body>$body</s:Body></s:Envelope>"""

    private fun post(url: String, xml: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 3000
            c.readTimeout = 4000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8")
            c.outputStream.use { it.write(xml.toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }

    /** Tenta cada URL, com senha em digest e depois em texto. Retorna o XML de resposta ou null. */
    fun call(urls: List<String>, user: String, pass: String, body: String): String? {
        for (u in urls) {
            for (digest in listOf(true, false)) {
                try {
                    val (code, text) = post(u, envelope(user, pass, body, digest))
                    if (code in 200..299) return text
                } catch (e: Exception) {
                    // tenta a próxima combinação
                }
            }
        }
        return null
    }

    fun xaddr(xml: String, service: String): String? =
        Regex("<(?:\\w+:)?$service>.*?<(?:\\w+:)?XAddr>(.*?)</(?:\\w+:)?XAddr>", RegexOption.DOT_MATCHES_ALL)
            .find(xml)?.groupValues?.get(1)?.trim()

    /** Escolhe o primeiro perfil que tenha PTZ; se nenhum tiver, o primeiro da lista. */
    fun profileToken(xml: String): String? {
        val r = Regex(
            "<(?:\\w+:)?Profiles\\b[^>]*?token=\"([^\"]+)\"[^>]*>(.*?)</(?:\\w+:)?Profiles>",
            RegexOption.DOT_MATCHES_ALL
        )
        val all = r.findAll(xml).toList()
        val withPtz = all.firstOrNull { it.groupValues[2].contains("PTZConfiguration") }
        return (withPtz ?: all.firstOrNull())?.groupValues?.get(1)
    }
}

class PtzClient(private val cam: Camera) {
    private val lock = Mutex()
    private var ptzUrl: String? = null
    private var token: String? = null

    var error by mutableStateOf<String?>(null)
        private set

    private fun fix(url: String): String {
        val m = Regex("^https?://([^/:]+)(:\\d+)?(/.*)?$").find(url) ?: return url
        val host = m.groupValues[1]
        val port = m.groupValues[2]
        val path = m.groupValues[3]
        return if (host == cam.host) url else "http://${cam.host}${port.ifEmpty { ":${cam.onvifPort}" }}$path"
    }

    private fun prepare(): Boolean {
        if (ptzUrl != null && token != null) return true
        val base = "http://${cam.host}:${cam.onvifPort}"
        val device = "$base/onvif/device_service"
        var media = "$base/onvif/media_service"
        var ptz = "$base/onvif/ptz_service"

        val caps = Onvif.call(
            listOf(device), cam.user, cam.pass,
            """<tds:GetCapabilities xmlns:tds="http://www.onvif.org/ver10/device/wsdl"><tds:Category>All</tds:Category></tds:GetCapabilities>"""
        )
        if (caps != null) {
            Onvif.xaddr(caps, "Media")?.let { media = fix(it) }
            Onvif.xaddr(caps, "PTZ")?.let { ptz = fix(it) }
        }
        val profiles = Onvif.call(
            listOf(media, device), cam.user, cam.pass,
            """<trt:GetProfiles xmlns:trt="http://www.onvif.org/ver10/media/wsdl"/>"""
        )
        if (profiles == null) {
            error = "ONVIF indisponível. Confira a porta ONVIF, o usuário e a senha."
            return false
        }
        val t = Onvif.profileToken(profiles)
        if (t == null) {
            error = "A câmera não informou um perfil ONVIF."
            return false
        }
        ptzUrl = ptz
        token = t
        error = null
        return true
    }

    suspend fun move(pan: Float, tilt: Float, zoom: Float) {
        lock.withLock {
            withContext<Unit>(Dispatchers.IO) {
                if (!prepare()) return@withContext
                val body =
                    """<tptz:ContinuousMove xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl" xmlns:tt="http://www.onvif.org/ver10/schema"><tptz:ProfileToken>$token</tptz:ProfileToken><tptz:Velocity><tt:PanTilt x="$pan" y="$tilt"/><tt:Zoom x="$zoom"/></tptz:Velocity></tptz:ContinuousMove>"""
                val r = Onvif.call(listOf(ptzUrl!!), cam.user, cam.pass, body)
                error = if (r == null) "A câmera não aceitou o comando (ela pode não ter motor PTZ)." else null
            }
        }
    }

    suspend fun stop() {
        lock.withLock {
            withContext<Unit>(Dispatchers.IO) {
                if (!prepare()) return@withContext
                val body =
                    """<tptz:Stop xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl"><tptz:ProfileToken>$token</tptz:ProfileToken><tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>"""
                Onvif.call(listOf(ptzUrl!!), cam.user, cam.pass, body)
                Unit
            }
        }
    }
}
