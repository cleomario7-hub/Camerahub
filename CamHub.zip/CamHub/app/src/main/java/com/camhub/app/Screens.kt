package com.camhub.app

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- tema

@Composable
fun CamHubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF4FC3F7),
            onPrimary = Color.Black,
            secondary = Color(0xFFFF5252),
            background = Color(0xFF101418),
            surface = Color(0xFF1A1F25),
        ),
        content = content,
    )
}

// ---------------------------------------------------------------- raiz

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CamHubApp() {
    val ctx = LocalContext.current
    val store = remember { CameraStore(ctx) }
    var cameras by remember { mutableStateOf(store.load()) }
    var tab by remember { mutableIntStateOf(0) }
    var full by remember { mutableStateOf<Pair<Camera, Int>?>(null) }
    var form by remember { mutableStateOf<Camera?>(null) }
    var showDiscover by remember { mutableStateOf(false) }

    fun persist(list: List<Camera>) {
        cameras = list
        store.save(list)
    }

    val f = full
    if (f != null) {
        FullscreenScreen(cam = f.first, initialLens = f.second, onBack = { full = null })
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("CamHub") },
                    actions = {
                        if (tab == 1) {
                            IconButton(onClick = { showDiscover = true }) {
                                Icon(Icons.Default.Search, "Buscar câmeras na rede")
                            }
                        }
                    },
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf(
                        "Ao vivo" to Icons.Default.Videocam,
                        "Câmeras" to Icons.Default.Settings,
                        "Gravações" to Icons.Default.VideoLibrary,
                    ).forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icon, label) },
                            label = { Text(label) },
                        )
                    }
                }
            },
            floatingActionButton = {
                if (tab == 1) {
                    FloatingActionButton(onClick = { form = Camera() }) {
                        Icon(Icons.Default.Add, "Adicionar câmera")
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> LiveScreen(
                        cameras = cameras,
                        onOpen = { c, lens -> full = c to lens },
                        onAdd = { tab = 1; form = Camera() },
                    )
                    1 -> CameraListScreen(
                        cameras = cameras,
                        onEdit = { form = it },
                        onDelete = { c -> persist(cameras.filter { it.id != c.id }) },
                    )
                    else -> RecordingsScreen()
                }
            }
        }

        form?.let { current ->
            CameraFormDialog(
                initial = current,
                isNew = cameras.none { it.id == current.id },
                onSave = { saved ->
                    persist(
                        if (cameras.any { it.id == saved.id }) cameras.map { if (it.id == saved.id) saved else it }
                        else cameras + saved
                    )
                    form = null
                },
                onDismiss = { form = null },
            )
        }

        if (showDiscover) {
            DiscoverDialog(
                onPick = { found ->
                    showDiscover = false
                    form = Camera(
                        name = found.label.ifBlank { "Câmera" },
                        host = found.host,
                        onvifPort = found.onvifPort ?: 80,
                    )
                },
                onDismiss = { showDiscover = false },
            )
        }
    }
}

// ---------------------------------------------------------------- player em Compose

@Composable
fun rememberStreamPlayer(cam: Camera, lens: Int): StreamPlayer {
    val ctx = LocalContext.current
    val player = remember(cam, lens) { StreamPlayer(ctx, cam, lens) }
    DisposableEffect(player) { onDispose { player.release() } }
    return player
}

@Composable
fun PlayerSurface(player: StreamPlayer, modifier: Modifier = Modifier) {
    key(player) {
        AndroidView(
            modifier = modifier,
            factory = { c -> VLCVideoLayout(c).also { player.attach(it) } },
        )
    }
}

@Composable
fun RecBadge(active: Boolean, modifier: Modifier = Modifier) {
    Row(
        modifier
            .background(Color(0xCCB71C1C), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Default.FiberManualRecord, null, tint = Color.White, modifier = Modifier.size(10.dp))
        Spacer(Modifier.width(4.dp))
        Text(if (active) "REC" else "REC (aguardando sinal)", color = Color.White, fontSize = 11.sp)
    }
}

@Composable
fun OverlayLabel(text: String) {
    Text(
        text,
        color = Color.White,
        fontSize = 12.sp,
        maxLines = 1,
        modifier = Modifier
            .background(Color(0x99000000), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

// ---------------------------------------------------------------- ao vivo

@Composable
fun LiveScreen(cameras: List<Camera>, onOpen: (Camera, Int) -> Unit, onAdd: () -> Unit) {
    var cols by remember { mutableIntStateOf(1) }
    val tiles = cameras.flatMap { c -> if (c.dual) listOf(c to 1, c to 2) else listOf(c to 1) }

    if (tiles.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Nenhuma câmera ainda.", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Cadastre uma câmera para ver as imagens ao vivo.", textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAdd) { Text("Adicionar câmera") }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = cols == 1, onClick = { cols = 1 }, label = { Text("1 coluna") })
                FilterChip(selected = cols == 2, onClick = { cols = 2 }, label = { Text("2 colunas") })
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(tiles, key = { "${it.first.id}-${it.second}" }) { (cam, lens) ->
                    StreamTile(cam, lens) { onOpen(cam, lens) }
                }
            }
        }
    }
}

@Composable
fun StreamTile(cam: Camera, lens: Int, onClick: () -> Unit) {
    val pl = rememberStreamPlayer(cam, lens)
    val title = if (cam.dual) "${cam.name} · Lente $lens" else cam.name
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(10.dp))
            .background(Color.Black)
    ) {
        PlayerSurface(pl, Modifier.fillMaxSize())
        Box(Modifier.matchParentSize().clickable(onClick = onClick))
        Column(Modifier.align(Alignment.TopStart).padding(6.dp)) {
            OverlayLabel(title)
            Spacer(Modifier.height(4.dp))
            OverlayLabel(pl.status)
        }
        if (pl.wantRecord) {
            RecBadge(pl.recording, Modifier.align(Alignment.TopEnd).padding(6.dp))
        }
        Row(Modifier.align(Alignment.BottomEnd)) {
            IconButton(onClick = { pl.toggleMute() }) {
                Icon(
                    if (pl.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                    "Áudio",
                    tint = Color.White,
                )
            }
            IconButton(onClick = { pl.toggleRecord() }) {
                Icon(
                    if (pl.wantRecord) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                    "Gravar",
                    tint = if (pl.wantRecord) Color.White else Color(0xFFFF5252),
                )
            }
        }
    }
}

// ---------------------------------------------------------------- tela cheia + controles

@Composable
fun FullscreenScreen(cam: Camera, initialLens: Int, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    var lens by remember { mutableIntStateOf(initialLens) }
    val pl = rememberStreamPlayer(cam, lens)
    val ptz = remember(cam) { PtzClient(cam) }
    var showPtz by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        PlayerSurface(pl, Modifier.fillMaxSize())

        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().background(Color(0x66000000)).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(
                    if (cam.dual) "${cam.name} · Lente $lens" else cam.name,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                )
                Text(pl.status, color = Color(0xCCFFFFFF), fontSize = 12.sp)
            }
            if (pl.wantRecord) RecBadge(pl.recording)
            Spacer(Modifier.width(8.dp))
        }

        if (showPtz) {
            PtzPad(ptz, Modifier.align(Alignment.CenterEnd).padding(12.dp))
        }

        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x66000000)).padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ControlButton(
                if (pl.wantRecord) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                if (pl.wantRecord) "Parar" else "Gravar",
                if (pl.wantRecord) Color.White else Color(0xFFFF5252),
            ) { pl.toggleRecord() }
            ControlButton(Icons.Default.CameraAlt, "Foto", Color.White) {
                val file = pl.snapshot()
                Toast.makeText(
                    ctx,
                    if (file != null) "Foto salva (aba Gravações)" else "Aguarde a imagem carregar",
                    Toast.LENGTH_SHORT,
                ).show()
            }
            ControlButton(
                if (pl.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                if (pl.muted) "Sem som" else "Som",
                Color.White,
            ) { pl.toggleMute() }
            ControlButton(Icons.Default.OpenWith, "PTZ", if (showPtz) MaterialTheme.colorScheme.primary else Color.White) {
                showPtz = !showPtz
            }
            if (cam.dual) {
                ControlButton(Icons.Default.Cameraswitch, "Lente ${if (lens == 1) 2 else 1}", Color.White) {
                    lens = if (lens == 1) 2 else 1
                }
            }
        }
    }
}

@Composable
fun ControlButton(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick) { Icon(icon, label, tint = tint) }
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

@Composable
fun PtzPad(ptz: PtzClient, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    fun go(p: Float, t: Float, z: Float) {
        scope.launch { ptz.move(p, t, z) }
    }
    fun halt() {
        scope.launch { ptz.stop() }
    }
    Column(
        modifier.background(Color(0x88000000), RoundedCornerShape(16.dp)).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        HoldButton(Icons.Default.KeyboardArrowUp, { go(0f, 0.5f, 0f) }, { halt() })
        Row {
            HoldButton(Icons.Default.KeyboardArrowLeft, { go(-0.5f, 0f, 0f) }, { halt() })
            Spacer(Modifier.size(60.dp))
            HoldButton(Icons.Default.KeyboardArrowRight, { go(0.5f, 0f, 0f) }, { halt() })
        }
        HoldButton(Icons.Default.KeyboardArrowDown, { go(0f, -0.5f, 0f) }, { halt() })
        Row {
            HoldButton(Icons.Default.ZoomOut, { go(0f, 0f, -0.5f) }, { halt() })
            HoldButton(Icons.Default.ZoomIn, { go(0f, 0f, 0.5f) }, { halt() })
        }
        ptz.error?.let {
            Text(it, color = Color(0xFFFFAB91), fontSize = 11.sp, modifier = Modifier.widthIn(max = 180.dp))
        }
    }
}

@Composable
fun HoldButton(icon: ImageVector, onDown: () -> Unit, onUp: () -> Unit) {
    Box(
        Modifier
            .padding(4.dp)
            .size(52.dp)
            .clip(CircleShape)
            .background(Color(0x55FFFFFF))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    onDown()
                    tryAwaitRelease()
                    onUp()
                })
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = Color.White)
    }
}

// ---------------------------------------------------------------- lista de câmeras

@Composable
fun CameraListScreen(cameras: List<Camera>, onEdit: (Camera) -> Unit, onDelete: (Camera) -> Unit) {
    var confirm by remember { mutableStateOf<Camera?>(null) }

    if (cameras.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(
                "Nenhuma câmera cadastrada.\nToque em + para adicionar ou na lupa para buscar na rede.",
                textAlign = TextAlign.Center,
            )
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(cameras, key = { it.id }) { c ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold)
                            Text("${c.host}:${c.rtspPort}", fontSize = 12.sp)
                            if (c.dual) Text("Duas lentes", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { onEdit(c) }) { Icon(Icons.Default.Edit, "Editar") }
                        IconButton(onClick = { confirm = c }) { Icon(Icons.Default.Delete, "Excluir") }
                    }
                }
            }
        }
    }

    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Excluir câmera?") },
            text = { Text(c.name) },
            confirmButton = { TextButton(onClick = { onDelete(c); confirm = null }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    number: Boolean = false,
    password: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        keyboardOptions = KeyboardOptions(
            keyboardType = if (number) KeyboardType.Number else if (password) KeyboardType.Password else KeyboardType.Text
        ),
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
    )
}

@Composable
fun CameraFormDialog(initial: Camera, isNew: Boolean, onSave: (Camera) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var host by remember { mutableStateOf(initial.host) }
    var rtspPort by remember { mutableStateOf(initial.rtspPort.toString()) }
    var user by remember { mutableStateOf(initial.user) }
    var pass by remember { mutableStateOf(initial.pass) }
    var path1 by remember { mutableStateOf(initial.path1) }
    var dual by remember { mutableStateOf(initial.dual) }
    var path2 by remember { mutableStateOf(initial.path2) }
    var onvifPort by remember { mutableStateOf(initial.onvifPort.toString()) }
    var lastPreset by remember { mutableStateOf<Preset?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Nova câmera" else "Editar câmera") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Modelo (preenche os caminhos padrão)", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
                    PRESETS.forEach { p ->
                        AssistChip(
                            onClick = {
                                lastPreset = p
                                path1 = p.path1
                                if (dual) path2 = p.path2
                                rtspPort = p.rtspPort.toString()
                                onvifPort = p.onvifPort.toString()
                                if (user.isBlank()) user = p.user
                            },
                            label = { Text(p.label) },
                            modifier = Modifier.padding(end = 6.dp),
                        )
                    }
                }
                Field("Nome", name, { name = it })
                Field("IP da câmera (ex.: 192.168.0.50)", host, { host = it })
                Field("Porta RTSP", rtspPort, { rtspPort = it }, number = true)
                Field("Usuário", user, { user = it })
                Field("Senha", pass, { pass = it }, password = true)
                Field("Caminho do vídeo (ou URL rtsp:// completa)", path1, { path1 = it })
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Câmera de duas lentes", Modifier.weight(1f))
                    Switch(checked = dual, onCheckedChange = {
                        dual = it
                        if (it && path2.isBlank()) path2 = lastPreset?.path2 ?: "/onvif2"
                        if (!it) path2 = ""
                    })
                }
                if (dual) Field("Caminho da lente 2", path2, { path2 = it })
                Field("Porta ONVIF (controle PTZ)", onvifPort, { onvifPort = it }, number = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = host.isNotBlank(),
                onClick = {
                    onSave(
                        Camera(
                            id = initial.id,
                            name = name.trim().ifBlank { host.trim() },
                            host = host.trim(),
                            rtspPort = rtspPort.toIntOrNull() ?: 554,
                            user = user.trim(),
                            pass = pass,
                            path1 = path1.trim(),
                            path2 = if (dual) path2.trim() else "",
                            onvifPort = onvifPort.toIntOrNull() ?: 80,
                        )
                    )
                },
            ) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun DiscoverDialog(onPick: (Found) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var results by remember { mutableStateOf<List<Found>>(emptyList()) }
    LaunchedEffect(Unit) {
        results = Discovery.run(ctx)
        loading = false
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Câmeras na rede") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (loading) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Procurando no Wi‑Fi…")
                    }
                } else if (results.isEmpty()) {
                    Text("Nenhuma câmera encontrada. Confirme que o celular está no mesmo Wi‑Fi das câmeras ou cadastre pelo IP.")
                } else {
                    Text("Toque na câmera para cadastrar:", fontSize = 12.sp)
                    results.forEach { f ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(f) }.padding(vertical = 10.dp)) {
                            Text(f.label, fontWeight = FontWeight.Bold)
                            Text(
                                f.host + (if (f.onvifPort != null) " · ONVIF ${f.onvifPort}" else "") +
                                    (if (f.rtsp) " · RTSP 554" else ""),
                                fontSize = 12.sp,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } },
    )
}

// ---------------------------------------------------------------- gravações e fotos

@Composable
fun RecordingsScreen() {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val items = remember(refresh) { Storage.listMedia(ctx) }
    var filter by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<MediaItem?>(null) }
    var toDelete by remember { mutableStateOf<MediaItem?>(null) }
    val shown = items.filter { filter == 0 || (filter == 1 && it.isVideo) || (filter == 2 && !it.isVideo) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filter == 0, onClick = { filter = 0 }, label = { Text("Tudo") })
            FilterChip(selected = filter == 1, onClick = { filter = 1 }, label = { Text("Vídeos") })
            FilterChip(selected = filter == 2, onClick = { filter = 2 }, label = { Text("Fotos") })
        }
        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Nada por aqui ainda.\nAbra uma câmera e toque em Gravar ou Foto.",
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(shown, key = { it.file.absolutePath }) { m ->
                    val date = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(m.file.lastModified()))
                    Card(Modifier.fillMaxWidth().clickable { open = m }) {
                        Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (m.isVideo) Icons.Default.Movie else Icons.Default.Image, null)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(m.camera, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(
                                    "$date · ${Formatter.formatShortFileSize(ctx, m.file.length())}",
                                    fontSize = 12.sp,
                                )
                            }
                            IconButton(onClick = { shareFile(ctx, m) }) { Icon(Icons.Default.Share, "Compartilhar") }
                            IconButton(onClick = { toDelete = m }) { Icon(Icons.Default.Delete, "Excluir") }
                        }
                    }
                }
            }
        }
    }

    open?.let { m ->
        if (m.isVideo) VideoPlayerDialog(m.file) { open = null } else PhotoDialog(m.file) { open = null }
    }

    toDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Excluir arquivo?") },
            text = { Text(m.file.name) },
            confirmButton = {
                TextButton(onClick = {
                    m.file.delete()
                    toDelete = null
                    refresh++
                }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }
}

fun shareFile(ctx: Context, m: MediaItem) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", m.file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = if (m.isVideo) "video/*" else "image/jpeg"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(send, "Compartilhar"))
}

@Composable
fun PhotoDialog(file: File, onClose: () -> Unit) {
    val bmp = remember(file) { BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap() }
    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(12.dp)) {
            if (bmp != null) {
                Image(bmp, null, Modifier.fillMaxWidth(), contentScale = ContentScale.Fit)
            } else {
                Text("Não foi possível abrir a imagem.", Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
fun VideoPlayerDialog(file: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { MediaPlayer(Vlc.get(ctx)) }
    var pos by remember { mutableFloatStateOf(0f) }
    var length by remember { mutableLongStateOf(1L) }
    var playing by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        onDispose {
            player.setEventListener(null)
            player.detachViews()
            Thread {
                try {
                    player.stop()
                    player.release()
                } catch (e: Throwable) {
                }
            }.start()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().padding(8.dp), shape = RoundedCornerShape(12.dp), color = Color.Black) {
            Column {
                Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(file.name, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Fechar", tint = Color.White) }
                }
                AndroidView(
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                    factory = { c ->
                        VLCVideoLayout(c).also { l ->
                            player.attachViews(l, null, false, true)
                            val m = Media(Vlc.get(c), Uri.fromFile(file))
                            player.setMedia(m)
                            m.release()
                            player.setEventListener { e ->
                                when (e.type) {
                                    MediaPlayer.Event.TimeChanged -> pos = e.timeChanged.toFloat()
                                    MediaPlayer.Event.LengthChanged -> length = e.lengthChanged.coerceAtLeast(1L)
                                    MediaPlayer.Event.Playing -> playing = true
                                    MediaPlayer.Event.Paused -> playing = false
                                    MediaPlayer.Event.EndReached -> playing = false
                                    else -> {}
                                }
                            }
                            player.play()
                        }
                    },
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        if (playing) player.pause() else player.play()
                    }) {
                        Icon(
                            if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                            if (playing) "Pausar" else "Reproduzir",
                            tint = Color.White,
                        )
                    }
                    Slider(
                        value = pos.coerceIn(0f, length.toFloat()),
                        onValueChange = { pos = it },
                        onValueChangeFinished = { player.setTime(pos.toLong()) },
                        valueRange = 0f..length.toFloat().coerceAtLeast(1f),
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}
