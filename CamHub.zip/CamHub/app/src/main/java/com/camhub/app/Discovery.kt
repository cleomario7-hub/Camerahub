package com.camhub.app

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLDecoder
import java.util.UUID

data class Found(val host: String, val onvifPort: Int?, val label: String, val rtsp: Boolean)

object Discovery {

    suspend fun run(ctx: Context): List<Found> = coroutineScope {
        val a = async(Dispatchers.IO) { onvifProbe(ctx) }
        val b = async(Dispatchers.IO) { scanRtsp() }
        val onvif = a.await()
        val rtsp = b.await()
        val map = LinkedHashMap<String, Found>()
        onvif.forEach { map[it.host] = it.copy(rtsp = it.host in rtsp) }
        rtsp.forEach { ip ->
            if (!map.containsKey(ip)) map[ip] = Found(ip, null, "Câmera (porta 554 aberta)", true)
        }
        map.values.toList()
    }

    private fun probeXml(): String =
        """<?xml version="1.0" encoding="UTF-8"?><e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" xmlns:dn="http://www.onvif.org/ver10/network/wsdl"><e:Header><w:MessageID>uuid:${UUID.randomUUID()}</w:MessageID><w:To e:mustUnderstand="true">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To><w:Action e:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header><e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body></e:Envelope>"""

    /** WS-Discovery (multicast UDP 3702): acha câmeras ONVIF na rede local. */
    private fun onvifProbe(ctx: Context): List<Found> {
        val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val lock = wifi?.createMulticastLock("camhub")
        lock?.setReferenceCounted(false)
        lock?.acquire()
        val out = LinkedHashMap<String, Found>()
        val s = DatagramSocket()
        try {
            s.soTimeout = 800
            val msg = probeXml().toByteArray()
            val group = InetAddress.getByName("239.255.255.250")
            repeat(2) { s.send(DatagramPacket(msg, msg.size, group, 3702)) }
            val end = System.currentTimeMillis() + 4000
            val buf = ByteArray(65535)
            while (System.currentTimeMillis() < end) {
                try {
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    parseProbe(String(p.data, 0, p.length))?.let { out[it.host] = it }
                } catch (e: SocketTimeoutException) {
                    // segue esperando até o tempo acabar
                }
            }
        } catch (e: Exception) {
            // sem resposta
        } finally {
            s.close()
            lock?.release()
        }
        return out.values.toList()
    }

    private fun parseProbe(xml: String): Found? {
        val xa = Regex("<(?:\\w+:)?XAddrs>(.*?)</(?:\\w+:)?XAddrs>", RegexOption.DOT_MATCHES_ALL)
            .find(xml)?.groupValues?.get(1) ?: return null
        val m = Regex("https?://(\\d+\\.\\d+\\.\\d+\\.\\d+)(?::(\\d+))?").find(xa) ?: return null
        val host = m.groupValues[1]
        val port = m.groupValues[2].toIntOrNull() ?: 80
        fun scope(key: String): String? =
            Regex("onvif://www\\.onvif\\.org/$key/([^\\s<]+)").find(xml)?.groupValues?.get(1)?.let {
                try { URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { it }
            }
        val label = listOfNotNull(scope("name"), scope("hardware")).distinct().joinToString(" ")
            .ifBlank { "Câmera ONVIF" }
        return Found(host, port, label, false)
    }

    private fun localIpv4(): String? = try {
        val ifaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
        ifaces.filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }
            ?.hostAddress
    } catch (e: Exception) {
        null
    }

    private fun isOpen(ip: String, port: Int, timeoutMs: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(ip, port), timeoutMs) }
        true
    } catch (e: Exception) {
        false
    }

    /** Varre a faixa /24 da rede procurando a porta RTSP (554) aberta. */
    private suspend fun scanRtsp(): List<String> = coroutineScope {
        val local = localIpv4() ?: return@coroutineScope emptyList<String>()
        val prefix = local.substringBeforeLast('.')
        (1..254).map { i ->
            async(Dispatchers.IO) {
                val ip = "$prefix.$i"
                if (ip != local && isOpen(ip, 554, 700)) ip else null
            }
        }.awaitAll().filterNotNull()
    }
}
