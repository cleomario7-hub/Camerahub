package com.camhub.app

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Instância única do LibVLC. */
object Vlc {
    @Volatile
    private var lib: LibVLC? = null

    fun get(ctx: Context): LibVLC = lib ?: synchronized(this) {
        lib ?: LibVLC(ctx.applicationContext, arrayListOf("--rtsp-tcp")).also { lib = it }
    }
}

data class MediaItem(val file: File, val camera: String, val isVideo: Boolean)

object Storage {
    fun root(ctx: Context): File = ctx.getExternalFilesDir(null) ?: ctx.filesDir

    fun safe(s: String): String =
        s.trim().replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").ifBlank { "camera" }

    fun recordDir(ctx: Context, camera: String): File =
        File(File(root(ctx), "Gravacoes"), safe(camera))

    fun photoDir(ctx: Context): File = File(root(ctx), "Fotos")

    fun listMedia(ctx: Context): List<MediaItem> {
        val out = mutableListOf<MediaItem>()
        File(root(ctx), "Gravacoes").listFiles()?.forEach { d ->
            if (d.isDirectory) {
                d.listFiles()?.forEach { f ->
                    if (f.isFile && f.length() > 0) out.add(MediaItem(f, d.name, true))
                }
            }
        }
        File(root(ctx), "Fotos").listFiles()?.forEach { f ->
            if (f.isFile && f.length() > 0) out.add(MediaItem(f, "Foto", false))
        }
        return out.sortedByDescending { it.file.lastModified() }
    }
}

/**
 * Um stream de uma câmera (lente 1 ou 2): reproduz ao vivo, reconecta sozinho,
 * grava em segmentos e tira fotos.
 */
class StreamPlayer(context: Context, val cam: Camera, val lens: Int) {
    private val ctx = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private val player = MediaPlayer(Vlc.get(ctx))
    private var layout: VLCVideoLayout? = null
    private var started = false
    private var released = false

    var status by mutableStateOf("Conectando…")
        private set
    var live by mutableStateOf(false)
        private set
    var recording by mutableStateOf(false)
        private set
    var wantRecord by mutableStateOf(false)
        private set
    var muted by mutableStateOf(true)
        private set

    private val retry = Runnable { if (!released) play() }

    private val segment = object : Runnable {
        override fun run() {
            if (released || !recording) return
            player.record(null)
            recording = player.record(currentDir().absolutePath)
            if (recording) handler.postDelayed(this, SEGMENT_MS)
        }
    }

    init {
        player.setVolume(0)
        player.setEventListener { e ->
            when (e.type) {
                MediaPlayer.Event.Playing -> {
                    live = true
                    status = "Ao vivo"
                    if (wantRecord && !recording) startRecord()
                }
                MediaPlayer.Event.Buffering -> {
                    if (!live) status = "Carregando ${e.buffering.toInt()}%"
                }
                MediaPlayer.Event.EncounteredError, MediaPlayer.Event.EndReached -> lost()
                else -> {}
            }
        }
    }

    fun attach(l: VLCVideoLayout) {
        if (released) return
        layout = l
        l.setBackgroundColor(android.graphics.Color.BLACK)
        player.attachViews(l, null, false, true)
        if (!started) {
            started = true
            play()
        }
    }

    private fun play() {
        if (released) return
        val media = Media(Vlc.get(ctx), Uri.parse(cam.url(lens)))
        media.setHWDecoderEnabled(true, false)
        media.addOption(":network-caching=500")
        media.addOption(":rtsp-tcp")
        if (cam.user.isNotBlank()) {
            media.addOption(":rtsp-user=${cam.user}")
            media.addOption(":rtsp-pwd=${cam.pass}")
        }
        player.setMedia(media)
        media.release()
        player.play()
    }

    private fun lost() {
        if (released) return
        live = false
        status = "Sem sinal — reconectando…"
        handler.removeCallbacks(segment)
        if (recording) {
            player.record(null)
            recording = false
        }
        handler.removeCallbacks(retry)
        handler.postDelayed(retry, 3000)
    }

    private fun currentDir(): File {
        val label = if (cam.dual) "${cam.name}_lente$lens" else cam.name
        val dir = Storage.recordDir(ctx, label)
        dir.mkdirs()
        return dir
    }

    fun toggleRecord() {
        if (wantRecord) {
            wantRecord = false
            stopRecord()
        } else {
            wantRecord = true
            if (live) startRecord()
        }
    }

    private fun startRecord() {
        recording = player.record(currentDir().absolutePath)
        handler.removeCallbacks(segment)
        if (recording) {
            handler.postDelayed(segment, SEGMENT_MS)
        } else {
            wantRecord = false
            status = "Falha ao iniciar a gravação"
        }
    }

    private fun stopRecord() {
        handler.removeCallbacks(segment)
        if (recording) player.record(null)
        recording = false
    }

    fun toggleMute() {
        muted = !muted
        player.setVolume(if (muted) 0 else 100)
    }

    /** Salva um JPEG do quadro atual. Retorna o arquivo ou null se ainda não há imagem. */
    fun snapshot(): File? {
        val l = layout ?: return null
        val tv = findTexture(l) ?: return null
        val bmp = tv.bitmap ?: return null
        val dir = Storage.photoDir(ctx)
        dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val f = File(dir, "${Storage.safe(cam.name)}_L${lens}_$stamp.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return f
    }

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                findTexture(v.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    fun release() {
        if (released) return
        released = true
        handler.removeCallbacksAndMessages(null)
        if (recording) player.record(null)
        recording = false
        player.setEventListener(null)
        player.detachViews()
        val p = player
        Thread {
            try {
                p.stop()
                p.release()
            } catch (e: Throwable) {
            }
        }.start()
    }

    companion object {
        /** Cada arquivo de gravação tem no máximo 10 minutos. */
        const val SEGMENT_MS = 10 * 60 * 1000L
    }
}
