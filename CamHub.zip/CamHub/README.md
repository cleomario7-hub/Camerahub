# CamHub — app Android para câmeras Wi‑Fi

Visualiza várias câmeras ao vivo, grava, tira fotos e controla PTZ.
Funciona com qualquer câmera que ofereça **RTSP** (e **ONVIF** para o PTZ).

## Como gerar o APK
1. Suba esta pasta para um repositório no GitHub (branch `main`).
2. O workflow `.github/workflows/main.yml` roda sozinho. Se precisar, vá em **Actions → Build APK → Run workflow**.
3. Baixe o artefato **CamHub-APK** e instale no celular.

## Como usar
1. Aba **Câmeras** → lupa para buscar na rede (ONVIF + porta 554) ou **+** para cadastrar pelo IP.
2. Escolha o modelo (YCC365 Plus, Yoosee, Tapo, Intelbras/Dahua, Hikvision) para preencher os caminhos padrão.
3. Câmera de duas lentes: ligue a chave "Câmera de duas lentes" — cada lente vira um quadro na aba **Ao vivo**.
4. Toque no vídeo para abrir em tela cheia: gravar, foto, som, PTZ e troca de lente.
5. Aba **Gravações**: reproduzir, compartilhar e excluir vídeos e fotos.

## Caminhos RTSP comuns
| Câmera | Caminho |
|---|---|
| YCC365 Plus / Yoosee | `/onvif1` (lente 2: `/onvif2`) |
| Tapo | `/stream1` / `/stream2` |
| Intelbras / Dahua | `/cam/realmonitor?channel=1&subtype=0` |
| Hikvision | `/Streaming/Channels/101` |

Se a câmera não abrir, teste primeiro no VLC (`rtsp://IP:554/onvif1`). Se não abrir lá, o app também não abre.

## Limites desta versão
- Grava só com o app aberto (a tela fica ligada). Gravação 24 h em segundo plano exige um serviço em primeiro plano.
- Sem detecção de movimento, sem leitura do cartão SD da câmera e sem áudio bidirecional.
- Só na mesma rede Wi‑Fi (fora de casa precisa de VPN ou redirecionamento de portas).
- Senhas ficam guardadas sem criptografia no aparelho.

Os arquivos ficam em `Android/data/com.camhub.app/files/` (`Gravacoes/` e `Fotos/`).
Vídeo via libVLC (LGPL).
